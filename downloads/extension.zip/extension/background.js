// Updated background.js with keyboard shortcuts support

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "readSelection",
    title: "Read Selection",
    contexts: ["selection"]
  });
});

// Keep track of current TTS utterance
let currentUtterance = null;
let isPaused = false;

// ----------------------
// Save History Locally
// ----------------------
function saveToHistory(text, rate, pitch, voiceName, url = null, pageTitle = null) {
  chrome.storage.local.get(["spokenHistory"], (res) => {
    const history = res.spokenHistory || [];

    history.unshift({
      text,
      rate,
      pitch,
      voiceName,
      timestamp: Date.now(),
      url,        // Store page URL
      pageTitle   // Store page title
    });

    if (history.length > 100) history.pop(); // limit
    chrome.storage.local.set({ spokenHistory: history });
  });
}

// ----------------------
// Chunking system
// ----------------------
function chunkText(text, chunkSize = 300) {
  const chunks = [];
  while (text.length > 0) {
    let chunk = text.slice(0, chunkSize);
    const lastPeriod = chunk.lastIndexOf(". ");
    if (lastPeriod !== -1 && lastPeriod > 100) {
      chunk = text.slice(0, lastPeriod + 1);
    }
    chunks.push(chunk.trim());
    text = text.slice(chunk.length);
  }
  return chunks;
}

function speakChunked(text, options = {}, callback) {
  const chunks = chunkText(text);
  let index = 0;

  function speakNext() {
    if (index >= chunks.length) {
      // Clear highlights if tabId is provided
      if (options.tabId) {
        chrome.scripting.executeScript({
          target: { tabId: options.tabId },
          func: () => document.querySelectorAll('.tts-highlight').forEach(el => el.classList.remove('tts-highlight'))
        });
      }
      if (typeof callback === "function") callback();
      return;
    }

    const chunk = chunks[index];

    // Highlight links containing chunk
    if (options.tabId) {
      chrome.scripting.executeScript({
        target: { tabId: options.tabId },
        func: (text) => {
          // Remove previous highlights
          document.querySelectorAll('.tts-highlight').forEach(el => el.classList.remove('tts-highlight'));

          // Highlight links containing text
          const links = Array.from(document.querySelectorAll('a'))
            .filter(a => a.innerText.includes(text));
          links.forEach(a => a.classList.add('tts-highlight'));
        },
        args: [chunk]
      });
    }

    chrome.tts.speak(chunk, {
      rate: options.rate || 1,
      pitch: options.pitch || 1,
      voiceName: options.voiceName || undefined,
      enqueue: false,
      onEvent(event) {
        if (event.type === "end" || event.type === "error") {
          index++;
          speakNext();
        }
      }
    });
  }

  speakNext();
}

// ----------------------
// Simple Text Summarizer
// ----------------------
function summarizeText(text, metaDescription = '', maxSentences = 5) {
  // Basic cleaning: remove extra spaces, newlines
  text = text.replace(/\s+/g, ' ').trim();

  // Split into sentences (simple regex for periods, question marks, etc.)
  const sentences = text.match(/[^.!?]+[.!?]+/g) || [text];

  // If there's a meta description, prepend it as the first "sentence"
  if (metaDescription) {
    sentences.unshift(metaDescription.trim());
  }

  // Simple scoring: score sentences by length (longer might be more informative) and uniqueness
  const wordFreq = {};
  text.split(' ').forEach(word => {
    word = word.toLowerCase().replace(/[^a-z]/g, '');
    if (word) wordFreq[word] = (wordFreq[word] || 0) + 1;
  });

  const scoredSentences = sentences.map(sentence => {
    const words = sentence.split(' ');
    let score = 0;
    words.forEach(word => {
      word = word.toLowerCase().replace(/[^a-z]/g, '');
      if (word && wordFreq[word]) score += wordFreq[word];
    });
    score /= words.length || 1; // Normalize by sentence length
    return { sentence: sentence.trim(), score };
  });

  // Sort by score descending and take top N
  scoredSentences.sort((a, b) => b.score - a.score);
  const topSentences = scoredSentences.slice(0, maxSentences).map(s => s.sentence);

  // Join into a summary
  let summary = topSentences.join(' ');
  
  // Fallback if summary is too short
  if (summary.length < 100 && sentences.length > 0) {
    summary = sentences.slice(0, Math.min(3, sentences.length)).join(' ');
  }

  return summary;
}

// ----------------------
// Helper to get clean text from tab
// ----------------------
async function getCleanTextFromTab(tabId) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      function getCleanText() {
        let main = document.querySelector('main') || document.querySelector('article') || document.querySelector('[role="main"]');
        let clone;
        if (main) {
          clone = main.cloneNode(true);
        } else {
          clone = document.body.cloneNode(true);
        }

        clone.querySelectorAll(
          'script, style, nav, header, footer, aside, [aria-hidden="true"], a.skip-link, iframe, .ad, .advert, .sidebar, [role="complementary"], [role="banner"], [role="contentinfo"]'
        ).forEach((el) => el.remove());

        return clone.innerText.trim();
      }

      return getCleanText();
    },
  });
  return result.result;
}

// ----------------------
// Helper to get meta description from tab
// ----------------------
async function getMetaDescriptionFromTab(tabId) {
  const [result] = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      return document.querySelector('meta[name="description"]')?.content || '';
    },
  });
  return result.result;
}

// ----------------------
// Context menu: read selection
// ----------------------
chrome.contextMenus.onClicked.addListener((info, tab) => {
  if (info.menuItemId === "readSelection") {
    chrome.storage.local.get(["speed", "pitch", "voiceName"], (settings) => {
      const rate = parseFloat(settings.speed) || 1;
      const pitch = parseFloat(settings.pitch) || 1;
      const voiceName = settings.voiceName || null;

      saveToHistory(info.selectionText, rate, pitch, voiceName, tab?.url, tab?.title);
      speakChunked(info.selectionText, { rate, pitch, voiceName });
    });
  }
});

// ----------------------
// Keyboard shortcuts listener
// ----------------------
chrome.commands.onCommand.addListener(async (command) => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  chrome.storage.local.get(["speed", "pitch", "voiceName"], async (settings) => {
    const rate = parseFloat(settings.speed) || 1;
    const pitch = parseFloat(settings.pitch) || 1;
    const voiceName = settings.voiceName || null;

    if (command === "read-page") {
      if (currentUtterance) chrome.tts.stop();
      isPaused = false;

      const cleanText = await getCleanTextFromTab(tab.id);
      const textToSpeak = cleanText.replace(/skip to content/gi, '').trim();

      currentUtterance = { text: textToSpeak, rate, pitch, voiceName };
      saveToHistory(textToSpeak, rate, pitch, voiceName, tab.url, tab.title);
      speakChunked(textToSpeak, { rate, pitch, voiceName, tabId: tab.id });
    } else if (command === "summarize-page") {
      if (currentUtterance) chrome.tts.stop();
      isPaused = false;

      const cleanText = await getCleanTextFromTab(tab.id);
      const description = await getMetaDescriptionFromTab(tab.id);
      const textToSummarize = cleanText.replace(/skip to content/gi, '').trim();

      let summary;
      if (!textToSummarize) {
        summary = "No content to summarize.";
      } else {
        summary = summarizeText(textToSummarize, description);
      }

      const prefixedSummary = summary.startsWith("No content") ? summary : `Summary: ${summary}`;

      currentUtterance = { text: prefixedSummary, rate, pitch, voiceName };
      saveToHistory(prefixedSummary, rate, pitch, voiceName, tab.url, tab.title);
      speakChunked(prefixedSummary, { rate, pitch, voiceName, tabId: tab.id });
    } else if (command === "stop-tts") {
      chrome.tts.stop();
      currentUtterance = null;
      isPaused = false;

      // Clear highlights
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        func: () => document.querySelectorAll('.tts-highlight').forEach(el => el.classList.remove('tts-highlight'))
      });
    } else if (command === "pause-resume-tts") {
      if (currentUtterance) {
        if (isPaused) {
          chrome.tts.resume();
          isPaused = false;
        } else {
          chrome.tts.pause();
          isPaused = true;
        }
      }
    }
  });
});

// ----------------------
// Single onMessage listener for popup/history messages
// ----------------------
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  chrome.storage.local.get(["speed", "pitch", "voiceName"], (settings) => {
    const rate = parseFloat(settings.speed) || 1;
    const pitch = parseFloat(settings.pitch) || 1;
    const voiceName = settings.voiceName || null;

    // ---------- READ PAGE ----------
    if (msg.action === "readText") {
      if (currentUtterance) chrome.tts.stop();
      isPaused = false;

      // Clean text to remove "skip to content" links or hidden elements
      const cleanText = msg.text.replace(/skip to content/gi, '').trim();

      currentUtterance = { text: cleanText, rate, pitch, voiceName };
      saveToHistory(cleanText, rate, pitch, voiceName, sender.tab?.url, sender.tab?.title);
      speakChunked(cleanText, { rate, pitch, voiceName, tabId: sender.tab?.id });
      sendResponse({ ok: true });
      return true;
    }

    // ---------- SUMMARIZE PAGE ----------
    if (msg.action === "summarizeText") {
      if (currentUtterance) chrome.tts.stop();
      isPaused = false;

      // Clean text
      const cleanText = msg.text.replace(/skip to content/gi, '').trim();

      let summary;
      if (!cleanText) {
        summary = "No content to summarize.";
      } else {
        // Generate summary
        summary = summarizeText(cleanText, msg.description || '');
      }

      // Prefix with "Summary:" for clarity
      const prefixedSummary = summary.startsWith("No content") ? summary : `Summary: ${summary}`;

      currentUtterance = { text: prefixedSummary, rate, pitch, voiceName };
      saveToHistory(prefixedSummary, rate, pitch, voiceName, sender.tab?.url, sender.tab?.title);
      speakChunked(prefixedSummary, { rate, pitch, voiceName, tabId: sender.tab?.id });
      sendResponse({ ok: true });
      return true;
    }

    // ---------- STOP ----------
    if (msg.action === "stopTTS") {
      chrome.tts.stop();
      currentUtterance = null;
      isPaused = false;

      // Clear highlights
      if (sender.tab?.id) {
        chrome.scripting.executeScript({
          target: { tabId: sender.tab.id },
          func: () => document.querySelectorAll('.tts-highlight').forEach(el => el.classList.remove('tts-highlight'))
        });
      }
      sendResponse({ ok: true });
      return true;
    }

    // ---------- PAUSE ----------
    if (msg.action === "pauseTTS") {
      if (currentUtterance && !isPaused) {
        chrome.tts.pause();
        isPaused = true;
      }
      sendResponse({ ok: true });
      return true;
    }

    // ---------- RESUME ----------
    if (msg.action === "resumeTTS") {
      if (currentUtterance && isPaused) {
        chrome.tts.resume();
        isPaused = false;
      }
      sendResponse({ ok: true });
      return true;
    }

    // ---------- UPDATE SPEED / PITCH ----------
    if (msg.action === "updateTTS") {
      if (msg.speed !== undefined) settings.speed = msg.speed;
      if (msg.pitch !== undefined) settings.pitch = msg.pitch;

      if (currentUtterance) {
        chrome.tts.stop();
        speakChunked(currentUtterance.text, { rate: settings.speed, pitch: settings.pitch, voiceName: settings.voiceName });
        isPaused = false;
      }
      sendResponse({ ok: true });
      return true;
    }

    // ---------- UPDATE VOICE ----------
    if (msg.action === "updateVoice") {
      if (msg.voiceName !== undefined) settings.voiceName = msg.voiceName;

      if (currentUtterance) {
        chrome.tts.stop();
        speakChunked(currentUtterance.text, { rate: settings.speed, pitch: settings.pitch, voiceName: msg.voiceName });
        isPaused = false;
      }
      sendResponse({ ok: true });
      return true;
    }

    // ---------- PLAY HISTORY ITEM (from history.html) ----------
    if (msg.action === "playHistoryItem") {
      if (msg.text) {
        speakChunked(msg.text, { rate, pitch, voiceName });
        sendResponse({ ok: true });
        return true;
      }
    }

    // no matched action
    sendResponse({ ok: false });
    return true;
  });

  return true; // will respond asynchronously
});
// extension/popup.js