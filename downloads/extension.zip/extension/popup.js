// =========================
// ELEMENT REFERENCES
// =========================
const readBtn = document.getElementById("readPage");
const stopBtn = document.getElementById("stop");
const pauseResumeBtn = document.getElementById("pauseResume");
const speedInput = document.getElementById("speed");
const speedVal = document.getElementById("speedVal");
const pitchInput = document.getElementById("pitch");
const pitchVal = document.getElementById("pitchVal");
const contrastInput = document.getElementById("contrast");
const contrastVal = document.getElementById("contrastVal");
const colorFilterInput = document.getElementById("colorFilter");
const themeToggle = document.getElementById("themeToggle");
const voiceSelect = document.getElementById("voiceSelect");
const resetSelect = document.getElementById("resetSelect");
const resetAllBtn = document.getElementById("resetAllBtn");
const openHistoryBtn = document.getElementById("openHistory");
const openDashboard = document.getElementById("openDashboard");
const summarizeBtn = document.getElementById("summarizePage");
const voiceControlBtn = document.getElementById("voiceControlBtn");
const openFeedbackPage = document.getElementById("openFeedbackPage");

let isPaused = false;
let recognition;
let isListening = false;

// =========================
// LOAD SAVED SETTINGS
// =========================
chrome.storage.local.get(
  ["speed", "pitch", "contrast", "colorFilter", "darkMode", "voiceName"],
  (data) => {
    if (data.speed) { speedInput.value = data.speed; speedVal.innerText = data.speed + "x"; }
    if (data.pitch) { pitchInput.value = data.pitch; pitchVal.innerText = data.pitch + "x"; }
    if (data.contrast) { contrastInput.value = data.contrast; contrastVal.innerText = data.contrast + "%"; }
    if (data.colorFilter) { colorFilterInput.value = data.colorFilter; }
    if (data.darkMode) { themeToggle.checked = data.darkMode; document.body.classList.toggle("dark", data.darkMode); }
    if (data.voiceName) { voiceSelect.value = data.voiceName; }
  }
);

// =========================
// SPEECH RECOGNITION
// =========================
function initSpeechRecognition() {
  if (!("webkitSpeechRecognition" in window)) { showToast("Speech recognition not supported."); return; }
  recognition = new webkitSpeechRecognition();
  recognition.continuous = true;
  recognition.interimResults = false;
  recognition.lang = "en-US";

  recognition.onresult = (event) => {
    const command = event.results[event.results.length - 1][0].transcript.trim().toLowerCase();
    handleVoiceCommand(command);
  };

  recognition.onerror = (event) => {
    if (event.error !== "no-speech") showToast(`Voice recognition error: ${event.error}`);
  };

  recognition.onend = () => {
    if (isListening) recognition.start();
  };
}

// =========================
// VOICE COMMAND HANDLER
// =========================
function handleVoiceCommand(command) {
  if (command.includes("read page") || command.includes("start reading")) { readBtn.click(); showToast("Reading page..."); }
  else if (command.includes("summarize page") || command.includes("summary")) { summarizeBtn.click(); showToast("Summarizing page..."); }
  else if (command.includes("pause") || command.includes("stop reading")) { if (!isPaused) pauseResumeBtn.click(); showToast("Paused"); }
  else if (command.includes("resume") || command.includes("continue")) { if (isPaused) pauseResumeBtn.click(); showToast("Resumed"); }
  else if (command.includes("stop") || command.includes("end")) { stopBtn.click(); showToast("Stopped"); }
  else if (command.includes("faster") || command.includes("increase speed")) { 
    speedInput.value = Math.min(parseFloat(speedInput.value)+0.1,2); 
    speedVal.innerText = speedInput.value+"x"; 
    chrome.storage.local.set({speed:speedInput.value}); 
    updateTTSSettings(); 
    showToast(`Speed set to ${speedInput.value}x`);
  }
  else if (command.includes("slower") || command.includes("decrease speed")) { 
    speedInput.value = Math.max(parseFloat(speedInput.value)-0.1,0.5); 
    speedVal.innerText = speedInput.value+"x"; 
    chrome.storage.local.set({speed:speedInput.value}); 
    updateTTSSettings(); 
    showToast(`Speed set to ${speedInput.value}x`);
  }
  else if (command.includes("reset")) { resetAllBtn.click(); showToast("Settings reset"); }
  else if (command.includes("stop listening")) { toggleVoiceControl(); }
  else { showToast(`Command not recognized: ${command}`); }
}

// =========================
// TOGGLE VOICE CONTROL
// =========================
voiceControlBtn.addEventListener("click", toggleVoiceControl);

function toggleVoiceControl() {
  if (!recognition) initSpeechRecognition();
  if (isListening) {
    recognition.stop(); isListening = false;
    voiceControlBtn.innerHTML = '<i class="fas fa-microphone"></i> Voice Control';
    voiceControlBtn.style.backgroundColor = "";
    showToast("Voice control stopped");
  } else {
    recognition.start(); isListening = true;
    voiceControlBtn.innerHTML = '<i class="fas fa-microphone-slash"></i> Stop Listening';
    voiceControlBtn.style.backgroundColor = "#ff4d4d";
    showToast("Voice control started. Speak commands like 'read page' or 'summarize'");
  }
}

// =========================
// READ PAGE CONTENT
// =========================
readBtn.addEventListener("click", () => {
  isPaused = false;
  pauseResumeBtn.innerHTML = '<i class="fas fa-pause"></i> Pause';
  chrome.tabs.query({ active:true, currentWindow:true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.scripting.executeScript({
      target: { tabId: tabs[0].id },
      func: () => {
        function getCleanText() {
          let main = document.querySelector("main")||document.querySelector("article")||document.querySelector('[role="main"]');
          let clone = main ? main.cloneNode(true) : document.body.cloneNode(true);
          clone.querySelectorAll('script, style, nav, header, footer, aside, [aria-hidden="true"], a.skip-link, iframe, .ad, .advert, .sidebar, [role="complementary"], [role="banner"], [role="contentinfo"]').forEach(el=>el.remove());
          return clone.innerText.trim();
        }
        chrome.runtime.sendMessage({ action:"readText", text:getCleanText() });
      }
    });
  });
});

// =========================
// STOP TTS
// =========================
stopBtn.addEventListener("click", () => {
  chrome.runtime.sendMessage({ action:"stopTTS" });
  isPaused = false;
  pauseResumeBtn.innerHTML = '<i class="fas fa-pause"></i> Pause';
});

// =========================
// PAUSE / RESUME
// =========================
pauseResumeBtn.addEventListener("click", () => {
  if (!isPaused) { chrome.runtime.sendMessage({action:"pauseTTS"}); pauseResumeBtn.innerHTML = '<i class="fas fa-play"></i> Resume'; isPaused=true; }
  else { chrome.runtime.sendMessage({action:"resumeTTS"}); pauseResumeBtn.innerHTML = '<i class="fas fa-pause"></i> Pause'; isPaused=false; }
});

// =========================
// TTS SPEED + PITCH
// =========================
function updateTTSSettings() {
  chrome.runtime.sendMessage({ action:"updateTTS", speed:parseFloat(speedInput.value), pitch:parseFloat(pitchInput.value) });
}

speedInput.addEventListener("input", (e) => { speedVal.innerText=e.target.value+"x"; chrome.storage.local.set({speed:e.target.value}); updateTTSSettings(); });
pitchInput.addEventListener("input", (e) => { pitchVal.innerText=e.target.value+"x"; chrome.storage.local.set({pitch:e.target.value}); updateTTSSettings(); });

// =========================
// CONTRAST & COLOR FILTER
// =========================
contrastInput.addEventListener("input", (e) => {
  const value = e.target.value;
  contrastVal.innerText = value+"%";
  chrome.storage.local.set({contrast:value});
  chrome.tabs.query({active:true,currentWindow:true},([tab])=>{
    if (!tab) return;
    chrome.scripting.executeScript({target:{tabId:tab.id}, func:(v)=>{document.body.style.filter=`contrast(${v}%)`}, args:[value]});
  });
});

colorFilterInput.addEventListener("change",(e)=>{
  const value=e.target.value;
  chrome.storage.local.set({colorFilter:value});
  chrome.tabs.query({active:true,currentWindow:true},([tab])=>{
    if (!tab) return;
    chrome.scripting.executeScript({target:{tabId:tab.id},func:(v)=>{document.body.style.filter=v}, args:[value]});
  });
});

// =========================
// DARK MODE
// =========================
themeToggle.addEventListener("change", ()=>{
  const isDark = themeToggle.checked;
  document.body.classList.toggle("dark", isDark);
  chrome.storage.local.set({darkMode:isDark});
});

// =========================
// LOAD VOICES
// =========================
chrome.tts.getVoices((voices)=>{
  voiceSelect.innerHTML="";
  voices.forEach(v=>{
    const option=document.createElement("option");
    option.value=v.voiceName;
    option.textContent=`${v.voiceName} (${v.lang})`;
    voiceSelect.appendChild(option);
  });
  chrome.storage.local.get("voiceName",(data)=>{
    if(data.voiceName) voiceSelect.value=data.voiceName;
  });
});

voiceSelect.addEventListener("change",(e)=>{
  chrome.storage.local.set({voiceName:e.target.value});
  chrome.runtime.sendMessage({action:"updateVoice",voiceName:e.target.value});
});

// =========================
// RESET BUTTONS
// =========================
resetAllBtn.addEventListener("click", ()=>{
  speedInput.value=1; pitchInput.value=1; contrastInput.value=100; colorFilterInput.value="none";
  speedVal.innerText="1x"; pitchVal.innerText="1x"; contrastVal.innerText="100%";
  chrome.storage.local.set({speed:1,pitch:1,contrast:100,colorFilter:"none",voiceName:null});
  chrome.tabs.query({active:true,currentWindow:true},([tab])=>{
    if(!tab)return;
    chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>{document.body.style.filter="none";}});
  });
  updateTTSSettings();
  chrome.runtime.sendMessage({action:"updateVoice",voiceName:null});
});

resetSelect.addEventListener("change",()=>{
  const type=resetSelect.value;
  if(!type) return;
  if(type==="speed"){ speedInput.value=1; speedVal.innerText="1x"; chrome.storage.local.set({speed:1}); updateTTSSettings(); }
  if(type==="pitch"){ pitchInput.value=1; pitchVal.innerText="1x"; chrome.storage.local.set({pitch:1}); updateTTSSettings(); }
  if(type==="contrast"){ contrastInput.value=100; contrastVal.innerText="100%"; chrome.storage.local.set({contrast:100}); chrome.tabs.query({active:true,currentWindow:true},([tab])=>{ if(!tab) return; chrome.scripting.executeScript({target:{tabId:tab.id}, func:()=>{document.body.style.filter="contrast(100%)"}}); }); }
  if(type==="colorFilter"){ colorFilterInput.value="none"; chrome.storage.local.set({colorFilter:"none"}); chrome.tabs.query({active:true,currentWindow:true},([tab])=>{ if(!tab) return; chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>{document.body.style.filter="none"}}); }); }
  if(type==="voice"){ chrome.storage.local.set({voiceName:null}); chrome.runtime.sendMessage({action:"updateVoice",voiceName:null}); }
  resetSelect.value="";
});

// =========================
// OPEN HISTORY / DASHBOARD / FEEDBACK
// =========================
openHistoryBtn.addEventListener("click", ()=>{
  chrome.tabs.create({url: chrome.runtime.getURL("history.html")});
});

openDashboard.addEventListener("click", ()=>{
  chrome.tabs.create({url:chrome.runtime.getURL("../dashboard/dashboard.html")});
});

openFeedbackPage.addEventListener("click", ()=>{
  chrome.tabs.create({url:chrome.runtime.getURL("../feedback/feedback.html")});
});

// =========================
// SUMMARIZE PAGE
// =========================
summarizeBtn.addEventListener("click",()=>{
  isPaused=false;
  pauseResumeBtn.innerHTML='<i class="fas fa-pause"></i> Pause';
  chrome.tabs.query({active:true,currentWindow:true},(tabs)=>{
    if(!tabs[0]) return;
    chrome.scripting.executeScript({
      target:{tabId:tabs[0].id},
      func:()=>{
        let main=document.querySelector("main")||document.querySelector("article")||document.querySelector('[role="main"]');
        let clone=main?main.cloneNode(true):document.body.cloneNode(true);
        clone.querySelectorAll('script, style, nav, header, footer, aside, [aria-hidden="true"], a.skip-link, iframe, .ad, .advert, .sidebar, [role="complementary"], [role="banner"], [role="contentinfo"]').forEach(el=>el.remove());
        const description=document.querySelector('meta[name="description"]')?.content||"";
        chrome.runtime.sendMessage({action:"summarizeText", text:clone.innerText.trim(), description:description});
      }
    });
  });
});

// =========================
// TOAST
// =========================
function showToast(message){
  const toast=document.getElementById("toast");
  toast.textContent=message;
  toast.classList.remove("hidden");
  toast.classList.add("show");
  setTimeout(()=>{ toast.classList.remove("show"); setTimeout(()=>toast.classList.add("hidden"),300); },2000);
}
